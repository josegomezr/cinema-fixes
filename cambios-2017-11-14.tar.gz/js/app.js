(function(){
	// formalidades para iniciar un modulo en angularjs
	var app = angular.module('cinema-room', ['ngRoute']);
	
})();